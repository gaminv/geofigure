#ifndef SHAPE_H
#define SHAPE_H
#include "base-types.h"
#include <iostream>
class Shape
{
public:
    virtual double getArea() = 0;
    virtual rectangle_t getFrameRect() = 0;
    virtual void move(double x, double y) = 0;
    virtual void move(point_t& newCentre) = 0;
    virtual void scale(double k) = 0;
    /*virtual std::string getName() = 0;*/
    //virtual clone() = 0;
};

#endif
