#include <iostream>

#include "rectangle.h"

int main()
{
	Rectangle rect(2, 2, 4);
	rect.getArea();
	rect.getFrameRect();
	rect.move(3.0, 3.0);
	rect.scale(2);
}