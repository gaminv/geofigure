#include "rectangle.h"

Rectangle::Rectangle(double leftX, double leftY, double length)
{
	leftPoint_.x = leftX;
	leftPoint_.y = leftY;
	rect_.height = length;
	rect_.width = length;
	rect_.pos.x = leftPoint_.x + (rect_.width / 2);
	rect_.pos.y = leftPoint_.y + (rect_.height / 2);
}

Rectangle::~Rectangle()
{
	std::cout << "destructor";
}

double Rectangle::getArea()
{
	return rect_.height * rect_.height;
}

rectangle_t Rectangle::getFrameRect()
{
	// �������������� �������������
	FrameRect_.height = rect_.height ;
	FrameRect_.width = rect_.width;
	FrameRect_.pos.x = rect_.pos.x;
	FrameRect_.pos.y = rect_.pos.y; 

	return FrameRect_;
}

void Rectangle::move(double x, double y)
{
	rect_.pos.x = x;
	rect_.pos.y = y;
	leftPoint_.x = x - (rect_.width / 2);
	leftPoint_.y = y - (rect_.height / 2);
}

void Rectangle::move(point_t& newCentre) // �������� �� ���� 
{
	rect_.pos.x += newCentre.x;
	rect_.pos.y += newCentre.y;
	leftPoint_.x = rect_.pos.x - (rect_.width / 2);
	leftPoint_.y = rect_.pos.y - (rect_.height / 2);
}

void Rectangle::scale(double k)
{
	rect_.height *= k;
	rect_.width *= k;
	leftPoint_.x = rect_.pos.x - (rect_.width / 2);
	leftPoint_.y = rect_.pos.y - (rect_.height / 2);
}

//std::string getName()
//{
//	return 0;
//}

